from ai_models.common.memory import ChatMemory

# Créer une session
session_id = ChatMemory.create_session()

# Ajouter des messages
ChatMemory.add_message(session_id, 'user', 'Salut, comment ça va ?')
ChatMemory.add_message(session_id, 'assistant', 'Ça va bien, merci !')

# Lire l'historique
history = ChatMemory.get_history(session_id)
print(history)
